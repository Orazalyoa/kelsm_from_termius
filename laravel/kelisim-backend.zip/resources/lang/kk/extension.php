<?php

return [
    'labels' => [
        'Extensions' => 'Кеңейтімдер',
    ],
    'fields' => [
        'alias'       => 'Бүркеншік ат',
        'description' => 'Сипаттама',
        'authors'     => 'Әзірлеушілер',
        'homepage'    => 'Басты бет',
        'require'     => 'Тәуелділіктер',
        'require_dev' => 'Әзірлеу ортасы тәуелділіктері',
        'name'        => 'Пакет аты',
        'version'     => 'Нұсқа',
        'enable'      => 'Қосу',
        'config'      => 'Конфигурация',
        'imported'    => 'Импортталған',
    ],
    'options' => [
    ],
];

