<?php if($grid->allowPagination()): ?>
    <div class="box-footer d-block clearfix ">
        <?php echo $grid->paginator()->render(); ?>

    </div>
<?php endif; ?>
<?php /**PATH E:\Codes\2025\kelisim\kelisim-backend\vendor\dcat\laravel-admin\src/../resources/views/grid/table-pagination.blade.php ENDPATH**/ ?>