<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Welcome to Kelisim Admin</h4>
            </div>
            <div class="card-body">
                <p>This is the admin dashboard for managing the Kelisim application.</p>
                <p>Use the sidebar navigation to access different management sections.</p>
            </div>
        </div>
    </div>
</div>

<?php /**PATH E:\Codes\2025\kelisim\kelisim-backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>